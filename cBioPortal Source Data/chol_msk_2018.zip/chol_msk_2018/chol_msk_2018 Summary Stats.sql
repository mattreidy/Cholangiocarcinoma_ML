use cBioPortal
/* Patient Stats */

select count (*) as Patient_Count from chol_msk_2018_patients 

select SEX as Gender, (Count(SEX)* 100.0 / (Select Count(*) From chol_msk_2018_patients)) as Pct from chol_msk_2018_patients group by SEX order by Pct desc 

select RACE as Race, (Count(RACE)* 100.0 / (Select Count(*) From chol_msk_2018_patients)) as Pct from chol_msk_2018_patients group by RACE order by Pct desc 

select AGE_CURRENT as Age_All from chol_msk_2018_patients order by AGE_CURRENT asc

select AGE_CURRENT as Age_Male from chol_msk_2018_patients where SEX='Male' order by AGE_CURRENT asc

select AGE_CURRENT as Age_Female from chol_msk_2018_patients where SEX='Female' order by AGE_CURRENT asc

select avg(AGE_CURRENT) as Avg_Age_All, min(AGE_CURRENT) as Min_Age_All, max(AGE_CURRENT) as Max_Age_All from chol_msk_2018_patients

select avg(AGE_CURRENT) as Avg_Age_Male, min(AGE_CURRENT) as Min_Age_Male, max(AGE_CURRENT) as Max_Age_Male from chol_msk_2018_patients where SEX='Male'

select avg(AGE_CURRENT) as Avg_Age_Female, min(AGE_CURRENT) as Min_Age_Female, max(AGE_CURRENT) as Max_Age_Female from chol_msk_2018_patients where SEX='Female'


select ceiling(OS_MONTHS/12) as OS_Yrs_All, 
	case
		when OS_STATUS = 'LIVING' then '0'
		when OS_STATUS = 'DECEASED' then '1'
	end as Died
from chol_msk_2018_patients 

select ceiling(OS_MONTHS/12) as OS_Yrs_All_Male, 
	case
		when OS_STATUS = 'LIVING' then '0'
		when OS_STATUS = 'DECEASED' then '1'
	end as Died
from chol_msk_2018_patients 
where SEX='Male'

select ceiling(OS_MONTHS/12) as OS_Yrs_All_Female, 
	case
		when OS_STATUS = 'LIVING' then '0'
		when OS_STATUS = 'DECEASED' then '1'
	end as Died
from chol_msk_2018_patients 
where SEX='Female'

select ceiling(chol_msk_2018_patients.OS_MONTHS/12) as OS_Yrs_All_IHCH, 
	case
		when chol_msk_2018_patients.OS_STATUS = 'LIVING' then '0'
		when chol_msk_2018_patients.OS_STATUS = 'DECEASED' then '1'
	end as Died
from chol_msk_2018_patients 
inner join chol_msk_2018_samples on chol_msk_2018_patients.PATIENT_ID=chol_msk_2018_samples.PATIENT_ID
where chol_msk_2018_samples.ONCOTREE_CODE='IHCH'

select ceiling(chol_msk_2018_patients.OS_MONTHS/12) as OS_Yrs_All_EHCH, 
	case
		when chol_msk_2018_patients.OS_STATUS = 'LIVING' then '0'
		when chol_msk_2018_patients.OS_STATUS = 'DECEASED' then '1'
	end as Died
from chol_msk_2018_patients 
inner join chol_msk_2018_samples on chol_msk_2018_patients.PATIENT_ID=chol_msk_2018_samples.PATIENT_ID
where chol_msk_2018_samples.ONCOTREE_CODE='EHCH'

select SYSTEMIC_TREATMENT as Systemic_Treatment, (Count(SYSTEMIC_TREATMENT)* 100.0 / (Select Count(*) From chol_msk_2018_patients)) as Pct from chol_msk_2018_patients group by SYSTEMIC_TREATMENT order by Pct desc 

/* Sample Stats */

select count (*) as Sample_Count from chol_msk_2018_samples

select avg(TIME_TO_METASTASIS_MONTHS) as Avg_Months_to_Mets, min(TIME_TO_METASTASIS_MONTHS) as Min_Months_to_Mets, max(TIME_TO_METASTASIS_MONTHS) as Max_Months_to_Mets from chol_msk_2018_samples where TIME_TO_METASTASIS_MONTHS > 0

select TIME_TO_METASTASIS_MONTHS as Months_to_Mets from chol_msk_2018_samples where TIME_TO_METASTASIS_MONTHS > 0 order by TIME_TO_METASTASIS_MONTHS asc

select (count(TIME_TO_METASTASIS_MONTHS)) / (select count(*)) as Pct_with_Mets from chol_msk_2018_samples where TIME_TO_METASTASIS_MONTHS > 0

select METASTATIC_SITE as Met_Site, (Count(METASTATIC_SITE)* 100.0 / (Select Count(*) From chol_msk_2018_samples where METASTATIC_SITE<>'Not Applicable')) as Pct from chol_msk_2018_samples where METASTATIC_SITE<>'Not Applicable' group by METASTATIC_SITE order by Pct desc 

select chol_msk_2018_samples.ONCOTREE_CODE as Male_Type, (count(chol_msk_2018_samples.ONCOTREE_CODE)*100.0/(select count(*) from chol_msk_2018_patients where chol_msk_2018_patients.SEX='Male')) as Pct
from chol_msk_2018_patients inner join chol_msk_2018_samples on chol_msk_2018_patients.PATIENT_ID=chol_msk_2018_samples.PATIENT_ID
where chol_msk_2018_patients.SEX='Male'
group by chol_msk_2018_samples.ONCOTREE_CODE

select chol_msk_2018_samples.ONCOTREE_CODE as Female_Type, (count(chol_msk_2018_samples.ONCOTREE_CODE)*100.0/(select count(*) from chol_msk_2018_patients where chol_msk_2018_patients.SEX='Female')) as Pct
from chol_msk_2018_patients inner join chol_msk_2018_samples on chol_msk_2018_patients.PATIENT_ID=chol_msk_2018_samples.PATIENT_ID
where chol_msk_2018_patients.SEX='Female'
group by chol_msk_2018_samples.ONCOTREE_CODE


select ONCOTREE_CODE as CC_Type, (Count(ONCOTREE_CODE)* 100.0 / (Select Count(*) From chol_msk_2018_samples)) as Pct from chol_msk_2018_samples group by ONCOTREE_CODE order by Pct desc

select TUMOR_PURITY as Tumor_Purity, (Count(TUMOR_PURITY)* 100.0 / (Select Count(*) From chol_msk_2018_samples where TUMOR_PURITY is not null)) as Pct from chol_msk_2018_samples where TUMOR_PURITY is not null group by TUMOR_PURITY order by Tumor_Purity asc

select MSI_TYPE as MSI, (Count(MSI_TYPE)* 100.0 / (Select Count(*) From chol_msk_2018_samples)) as Pct from chol_msk_2018_samples group by MSI_TYPE order by Pct desc

select CVR_TMB_SCORE as TMB_Score, (Count(CVR_TMB_SCORE)* 100.0 / (Select Count(*) From chol_msk_2018_samples where CVR_TMB_SCORE is not null)) as Pct from chol_msk_2018_samples where CVR_TMB_SCORE is not null group by CVR_TMB_SCORE order by TMB_Score asc

select CVR_TMB_SCORE as TMB_Score From chol_msk_2018_samples where CVR_TMB_SCORE is not null

/* Mutation Stats */
select Hugo_Symbol as Genes_All_Alpha, (Count(Hugo_Symbol)* 100.0 / (Select Count(*) From chol_msk_2018_mutations)) as Pct from chol_msk_2018_mutations group by Hugo_Symbol order by Hugo_Symbol asc

select Hugo_Symbol as Genes_All_Pct, (Count(Hugo_Symbol)* 100.0 / (Select Count(*) From chol_msk_2018_mutations)) as Pct from chol_msk_2018_mutations group by Hugo_Symbol order by Pct desc, Hugo_Symbol asc

select Variant_Type as Variant_Type_All, (Count(Variant_Type)* 100.0 / (Select Count(*) From chol_msk_2018_mutations)) as Pct from chol_msk_2018_mutations group by Variant_Type order by Pct desc


select chol_msk_2018_mutations.Hugo_Symbol as Genes_IHCH, (Count(chol_msk_2018_mutations.Hugo_Symbol)* 100.0 / (Select Count(*) From chol_msk_2018_mutations)) as Pct 
from chol_msk_2018_mutations inner join chol_msk_2018_samples on chol_msk_2018_mutations.Tumor_Sample_Barcode=chol_msk_2018_samples.SAMPLE_ID 
where chol_msk_2018_samples.ONCOTREE_CODE='IHCH'
group by chol_msk_2018_mutations.Hugo_Symbol order by Pct desc, Hugo_Symbol asc

select chol_msk_2018_mutations.Hugo_Symbol as Genes_EHCH, (Count(chol_msk_2018_mutations.Hugo_Symbol)* 100.0 / (Select Count(*) From chol_msk_2018_mutations)) as Pct 
from chol_msk_2018_mutations inner join chol_msk_2018_samples on chol_msk_2018_mutations.Tumor_Sample_Barcode=chol_msk_2018_samples.SAMPLE_ID 
where chol_msk_2018_samples.ONCOTREE_CODE='EHCH'
group by chol_msk_2018_mutations.Hugo_Symbol order by Pct desc, Hugo_Symbol asc

select chol_msk_2018_mutations.Hugo_Symbol as Genes_Male_All, (Count(chol_msk_2018_mutations.Hugo_Symbol)* 100.0 / (Select Count(*) From chol_msk_2018_mutations)) as Pct 
from chol_msk_2018_mutations 
inner join chol_msk_2018_samples on chol_msk_2018_mutations.Tumor_Sample_Barcode=chol_msk_2018_samples.SAMPLE_ID 
inner join  chol_msk_2018_patients on chol_msk_2018_samples.PATIENT_ID=chol_msk_2018_patients.PATIENT_ID
where chol_msk_2018_patients.SEX='Male'
group by chol_msk_2018_mutations.Hugo_Symbol order by Pct desc, Hugo_Symbol asc

select chol_msk_2018_mutations.Hugo_Symbol as Genes_Male_IHCH, (Count(chol_msk_2018_mutations.Hugo_Symbol)* 100.0 / (Select Count(*) From chol_msk_2018_mutations)) as Pct 
from chol_msk_2018_mutations 
inner join chol_msk_2018_samples on chol_msk_2018_mutations.Tumor_Sample_Barcode=chol_msk_2018_samples.SAMPLE_ID 
inner join  chol_msk_2018_patients on chol_msk_2018_samples.PATIENT_ID=chol_msk_2018_patients.PATIENT_ID
where chol_msk_2018_patients.SEX='Male' and chol_msk_2018_samples.ONCOTREE_CODE='IHCH'
group by chol_msk_2018_mutations.Hugo_Symbol order by Pct desc, Hugo_Symbol asc

select chol_msk_2018_mutations.Hugo_Symbol as Genes_Male_EHCH, (Count(chol_msk_2018_mutations.Hugo_Symbol)* 100.0 / (Select Count(*) From chol_msk_2018_mutations)) as Pct 
from chol_msk_2018_mutations 
inner join chol_msk_2018_samples on chol_msk_2018_mutations.Tumor_Sample_Barcode=chol_msk_2018_samples.SAMPLE_ID 
inner join  chol_msk_2018_patients on chol_msk_2018_samples.PATIENT_ID=chol_msk_2018_patients.PATIENT_ID
where chol_msk_2018_patients.SEX='Male' and chol_msk_2018_samples.ONCOTREE_CODE='EHCH'
group by chol_msk_2018_mutations.Hugo_Symbol order by Pct desc, Hugo_Symbol asc

select chol_msk_2018_mutations.Hugo_Symbol as Genes_Female_All, (Count(chol_msk_2018_mutations.Hugo_Symbol)* 100.0 / (Select Count(*) From chol_msk_2018_mutations)) as Pct 
from chol_msk_2018_mutations 
inner join chol_msk_2018_samples on chol_msk_2018_mutations.Tumor_Sample_Barcode=chol_msk_2018_samples.SAMPLE_ID 
inner join  chol_msk_2018_patients on chol_msk_2018_samples.PATIENT_ID=chol_msk_2018_patients.PATIENT_ID
where chol_msk_2018_patients.SEX='Female'
group by chol_msk_2018_mutations.Hugo_Symbol order by Pct desc, Hugo_Symbol asc

select chol_msk_2018_mutations.Hugo_Symbol as Genes_Female_IHCH, (Count(chol_msk_2018_mutations.Hugo_Symbol)* 100.0 / (Select Count(*) From chol_msk_2018_mutations)) as Pct 
from chol_msk_2018_mutations 
inner join chol_msk_2018_samples on chol_msk_2018_mutations.Tumor_Sample_Barcode=chol_msk_2018_samples.SAMPLE_ID 
inner join  chol_msk_2018_patients on chol_msk_2018_samples.PATIENT_ID=chol_msk_2018_patients.PATIENT_ID
where chol_msk_2018_patients.SEX='Female' and chol_msk_2018_samples.ONCOTREE_CODE='IHCH'
group by chol_msk_2018_mutations.Hugo_Symbol order by Pct desc, Hugo_Symbol asc

select chol_msk_2018_mutations.Hugo_Symbol as Genes_Female_EHCH, (Count(chol_msk_2018_mutations.Hugo_Symbol)* 100.0 / (Select Count(*) From chol_msk_2018_mutations)) as Pct 
from chol_msk_2018_mutations 
inner join chol_msk_2018_samples on chol_msk_2018_mutations.Tumor_Sample_Barcode=chol_msk_2018_samples.SAMPLE_ID 
inner join  chol_msk_2018_patients on chol_msk_2018_samples.PATIENT_ID=chol_msk_2018_patients.PATIENT_ID
where chol_msk_2018_patients.SEX='Female' and chol_msk_2018_samples.ONCOTREE_CODE='EHCH'
group by chol_msk_2018_mutations.Hugo_Symbol order by Pct desc, Hugo_Symbol asc


select chol_msk_2018_mutations.Hugo_Symbol as Genes_IHCH, (Count(chol_msk_2018_mutations.Hugo_Symbol)* 100.0 / (Select Count(*) From chol_msk_2018_mutations)) as Pct 
from chol_msk_2018_mutations inner join chol_msk_2018_samples on chol_msk_2018_mutations.Tumor_Sample_Barcode=chol_msk_2018_samples.SAMPLE_ID 
where chol_msk_2018_samples.ONCOTREE_CODE='IHCH'
group by chol_msk_2018_mutations.Hugo_Symbol order by Pct desc, Hugo_Symbol asc

/* average number of Hugo_Symbol per Tumor_Sample_Barcode */

select count(Hugo_Symbol) as Genes_Per_Sample_All from chol_msk_2018_mutations group by Tumor_Sample_Barcode

select count(chol_msk_2018_mutations.Hugo_Symbol) as Genes_Per_Sample_Male from chol_msk_2018_mutations 
inner join chol_msk_2018_samples on chol_msk_2018_mutations.Tumor_Sample_Barcode=chol_msk_2018_samples.SAMPLE_ID 
inner join  chol_msk_2018_patients on chol_msk_2018_samples.PATIENT_ID=chol_msk_2018_patients.PATIENT_ID
where chol_msk_2018_patients.SEX='Male'
group by chol_msk_2018_mutations.Hugo_Symbol

select count(chol_msk_2018_mutations.Hugo_Symbol) as Genes_Per_Sample_Female from chol_msk_2018_mutations 
inner join chol_msk_2018_samples on chol_msk_2018_mutations.Tumor_Sample_Barcode=chol_msk_2018_samples.SAMPLE_ID 
inner join  chol_msk_2018_patients on chol_msk_2018_samples.PATIENT_ID=chol_msk_2018_patients.PATIENT_ID
where chol_msk_2018_patients.SEX='Female'
group by chol_msk_2018_mutations.Hugo_Symbol

select count(chol_msk_2018_mutations.Hugo_Symbol) as Genes_Per_Sample_IHCH from chol_msk_2018_mutations 
inner join chol_msk_2018_samples on chol_msk_2018_mutations.Tumor_Sample_Barcode=chol_msk_2018_samples.SAMPLE_ID 
inner join  chol_msk_2018_patients on chol_msk_2018_samples.PATIENT_ID=chol_msk_2018_patients.PATIENT_ID
where chol_msk_2018_samples.ONCOTREE_CODE='IHCH'
group by chol_msk_2018_mutations.Hugo_Symbol

select count(chol_msk_2018_mutations.Hugo_Symbol) as Genes_Per_Sample_EHCH from chol_msk_2018_mutations 
inner join chol_msk_2018_samples on chol_msk_2018_mutations.Tumor_Sample_Barcode=chol_msk_2018_samples.SAMPLE_ID 
inner join  chol_msk_2018_patients on chol_msk_2018_samples.PATIENT_ID=chol_msk_2018_patients.PATIENT_ID
where chol_msk_2018_samples.ONCOTREE_CODE='EHCH'
group by chol_msk_2018_mutations.Hugo_Symbol

/* number of different genes */
select count(distinct Hugo_Symbol) as Different_Genes_All from chol_msk_2018_mutations

select count(distinct chol_msk_2018_mutations.Hugo_Symbol) as Different_Genes_IHCH from chol_msk_2018_mutations 
inner join chol_msk_2018_samples on chol_msk_2018_mutations.Tumor_Sample_Barcode=chol_msk_2018_samples.SAMPLE_ID 
inner join  chol_msk_2018_patients on chol_msk_2018_samples.PATIENT_ID=chol_msk_2018_patients.PATIENT_ID
where chol_msk_2018_samples.ONCOTREE_CODE='IHCH'

select count(distinct chol_msk_2018_mutations.Hugo_Symbol) as Different_Genes_EHCH from chol_msk_2018_mutations 
inner join chol_msk_2018_samples on chol_msk_2018_mutations.Tumor_Sample_Barcode=chol_msk_2018_samples.SAMPLE_ID 
inner join  chol_msk_2018_patients on chol_msk_2018_samples.PATIENT_ID=chol_msk_2018_patients.PATIENT_ID
where chol_msk_2018_samples.ONCOTREE_CODE='EHCH'



