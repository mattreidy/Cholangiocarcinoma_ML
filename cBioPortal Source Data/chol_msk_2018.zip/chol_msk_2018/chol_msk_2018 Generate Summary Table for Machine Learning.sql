use cBioPortal
DECLARE @Columns NVARCHAR(MAX),
@SQL NVARCHAR(MAX);
SELECT @Columns = ( SELECT CHAR(10) + CHAR(9) + ',MAX( CASE WHEN m.hugo_symbol = ' + QUOTENAME( hugo_symbol, '''') + ' THEN 1 ELSE 0 END) AS ' +  QUOTENAME(hugo_symbol)
                FROM chol_msk_2018_mutations
                GROUP BY hugo_symbol
                FOR XML PATH(''), TYPE).value('./text()[1]', 'nvarchar(max)')

SET @SQL = N'SELECT s.sample_id ' + NCHAR(10)
         + @Columns + NCHAR(10)
         + N'FROM chol_msk_2018_samples s ' + NCHAR(10)
         + N'LEFT JOIN chol_msk_2018_mutations m ON s.sample_id = m.tumor_sample_barcode ' + NCHAR(10)
         + N'GROUP BY s.patient_id, ' + NCHAR(10)
         + N'        s.sample_id;' + NCHAR(10)

execute sp_executesql @SQL

use cBioPortal
DECLARE @Columns NVARCHAR(MAX),
@SQL NVARCHAR(MAX);
SELECT @Columns = ( SELECT CHAR(10) + CHAR(9) + ',MAX( CASE WHEN m.hugo_symbol = ' + QUOTENAME( hugo_symbol, '''') + ' THEN 1 ELSE 0 END) AS ' +  QUOTENAME(hugo_symbol)
                FROM msk_impact_2017_mutations
                GROUP BY hugo_symbol
                FOR XML PATH(''), TYPE).value('./text()[1]', 'nvarchar(max)')

SET @SQL = N'SELECT s.sample_id ' + NCHAR(10)
         + @Columns + NCHAR(10)
         + N'FROM msk_impact_2017_samples s ' + NCHAR(10)
         + N'LEFT JOIN msk_impact_2017_mutations m ON s.sample_id = m.tumor_sample_barcode ' + NCHAR(10)
         + N'GROUP BY s.patient_id, ' + NCHAR(10)
         + N'        s.sample_id;' + NCHAR(10)

execute sp_executesql @SQL

